
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import urllib.request
import urllib.error
from urllib.parse import urljoin, quote
import concurrent.futures
import threading
import time
import queue
import re
import html
import unicodedata


APP_NAME = "MarianTel Stream Scanner"

# Ile bajtów pierwszego segmentu pobieramy, żeby odczytać nazwę usługi
# z tabeli SDT (tak samo robi VLC dla strumieni MPEG-TS).
SEGMENT_PROBE_BYTES = 768 * 1024

PL_FILTERS = ("Wszystkie", "PL i prawdopodobne", "Tylko PL")

# Blokada kanałów erotycznych / XXX (nazwa, grupa, dostawca, adres).
ADULT_RE = re.compile(
    r"(?<![a-z])(?:erot(?:ic|ik|yk|ycz)|porn|xxx(?![a-z]))",
    re.IGNORECASE
)


def is_adult(fields):
    return any(ADULT_RE.search(f or "") for f in fields)


def retries_for(details):
    """Ile razy ponowić sprawdzenie po błędzie przejściowym."""
    d = (details or "").lower()

    if re.search(r"http (429|5\d\d)|reset|closed|too many|aborted", d):
        return 2

    if "timed out" in d or "timeout" in d:
        return 1

    return 0

# Przykładowa lista nazw (slugów) do trybu "Lista nazw".
# Możesz ją dowolnie edytować w programie albo wczytać własny plik .txt.
DEFAULT_NAMES = """
tvp1
tvp2
tvp3
tvp-info
tvp-rozrywka
tvp-seriale
tvp-kultura
tvp-historia
tvp-polonia
tvp-sport
tvp-world
tvp-dokument
tvp-nauka
tvp-kobieta
tvp-abc
polsat
polsat-news
polsat-film
polsat-cafe
polsat-play
polsat-rodzina
polsat-seriale
polsat-sport
polsat-sport-extra
polsat-doku
polsat-games
super-polsat
tvn
tvn7
tvn24
tvn24-biznes
tvn-turbo
tvn-style
tvn-fabula
ttv
tv4
tv6
tv-puls
puls-2
tv-republika
wpolsce24
canal-plus
canal-plus-family
canal-plus-seriale
canal-plus-sport
canal-plus-film
hbo
hbo2
hbo3
cinemax
cinemax2
axn
axn-white
axn-black
comedy-central
mtv
mtv-polska
vh1
4fun-tv
polo-tv
eska-tv
eska-rock-tv
nuta-tv
stopklatka
metro
zoom-tv
nowa-tv
fokus-tv
tv-trwam
discovery-channel
tlc
animal-planet
national-geographic
nat-geo-wild
history
eurosport-1
eurosport-2
cartoon-network
nickelodeon
disney-channel
minimax
teletoon
boomerang
""".strip()

# Starszy format: sam numer tuż przed /index.m3u8
LEGACY_RE = re.compile(
    r"/(\d+)(?=/index\.m3u8(?:\?|$))", re.IGNORECASE
)
BRACKET_RE = re.compile(r"\[([^\[\]]*)\]")


# ----------------------------------------------------------------------
# Wykrywanie PL
# ----------------------------------------------------------------------

# Wyraźny znacznik w nazwie/grupie: "PL", "PL|", "[PL]", "TVP1 PL", "Poland"...
PL_EXPLICIT_RE = re.compile(
    r"(?<![A-Za-z0-9])"
    r"(?:pl|poland|polska|polish|polski|polskie|polskich)"
    r"(?![A-Za-z0-9])",
    re.IGNORECASE
)

# Metadane (tvg-country=PL, tvg-language=Polish, tvg-id=TVP1.pl ...)
PL_META_RE = re.compile(
    r"(?<![A-Za-z0-9])"
    r"(?:pl|pol|polish|poland|polska|polski)"
    r"(?![A-Za-z0-9])",
    re.IGNORECASE
)

PL_DIACRITICS_RE = re.compile(r"[ąćęłńóśźżĄĆĘŁŃÓŚŹŻ]")

# Znane polskie marki - to tylko "prawdopodobne" (pl?).
PL_BRANDS_RE = re.compile(
    r"(?<![a-z0-9])(?:"
    r"tvp|polsat|tvn|tv[ _-]?puls|puls[ _-]?2|tv[ _-]?republika|"
    r"wpolsce|eska|polo[ _-]?tv|4fun|nuta|stopklatka|trwam|"
    r"kino[ _-]?polska|ale[ _-]?kino|fokus[ _-]?tv|nowa[ _-]?tv|"
    r"zoom[ _-]?tv|tv4|tv6|ttv"
    r")",
    re.IGNORECASE
)


def detect_pl(fields, meta=(), hints=()):
    """Zwraca "PL" (pewne), "pl?" (prawdopodobne) albo ""."""
    for f in fields:
        if f and PL_EXPLICIT_RE.search(f):
            return "PL"

    for m in meta:
        if m and PL_META_RE.search(m):
            return "PL"

    for f in list(fields) + list(hints):
        if not f:
            continue

        if (
            PL_DIACRITICS_RE.search(f)
            or PL_BRANDS_RE.search(f)
            or PL_EXPLICIT_RE.search(f)
        ):
            return "pl?"

    return ""


# ----------------------------------------------------------------------
# Odczyt nazwy usługi z MPEG-TS (tabela SDT, PID 0x11)
# ----------------------------------------------------------------------

_DVB_8859 = {1: 5, 2: 6, 3: 7, 4: 8, 5: 9, 6: 10, 7: 11, 9: 13, 10: 14, 11: 15}


def dvb_text(raw):
    if not raw:
        return ""

    first = raw[0]
    enc = None

    if first == 0x15:
        return raw[1:].decode("utf-8", errors="replace")

    if first == 0x10 and len(raw) >= 3:
        enc = f"iso8859-{(raw[1] << 8) | raw[2]}"
        raw = raw[3:]
    elif first in _DVB_8859:
        enc = f"iso8859-{_DVB_8859[first]}"
        raw = raw[1:]
    elif first < 0x20:
        raw = raw[1:]

    if enc:
        try:
            return raw.decode(enc)
        except (LookupError, UnicodeDecodeError):
            pass

    for e in ("utf-8", "cp1250", "latin-1"):
        try:
            return raw.decode(e)
        except UnicodeDecodeError:
            continue

    return raw.decode("latin-1", errors="replace")


def clean_text(s):
    s = re.sub(r"[\x00-\x1f\x7f-\x9f\ue080-\ue09f]", "", s)
    return s.strip()


def parse_sdt_section(sec):
    end = len(sec) - 4  # bez CRC
    pos = 11

    while pos + 5 <= end:
        dll = ((sec[pos + 3] & 0x0F) << 8) | sec[pos + 4]
        d = pos + 5
        d_end = min(d + dll, end)

        while d + 2 <= d_end:
            tag = sec[d]
            ln = sec[d + 1]
            body = sec[d + 2:d + 2 + ln]

            # 0x48 = service_descriptor
            if tag == 0x48 and len(body) >= 3:
                plen = body[1]
                provider = body[2:2 + plen]

                if 2 + plen < len(body):
                    slen = body[2 + plen]
                    sname = body[3 + plen:3 + plen + slen]
                    name = clean_text(dvb_text(sname))

                    if name:
                        return name, clean_text(dvb_text(provider))

            d += 2 + ln

        pos = d_end

    return "", ""


def parse_ts_service(data):
    """Zwraca (nazwa_usługi, nazwa_dostawcy) z surowych bajtów MPEG-TS."""
    n = len(data)
    start = -1

    for i in range(min(188, n)):
        if (
            i + 376 < n
            and data[i] == 0x47
            and data[i + 188] == 0x47
            and data[i + 376] == 0x47
        ):
            start = i
            break

    if start < 0:
        return "", ""

    buf = None
    pos = start

    while pos + 188 <= n:
        p = data[pos:pos + 188]
        pos += 188

        if p[0] != 0x47:
            continue

        pid = ((p[1] & 0x1F) << 8) | p[2]

        if pid != 0x11:
            continue

        pusi = p[1] & 0x40
        afc = (p[3] >> 4) & 3

        if afc in (0, 2):
            continue

        off = 4

        if afc == 3:
            off += 1 + p[4]

        if off >= 188:
            continue

        payload = p[off:]

        if pusi:
            ptr = payload[0]
            buf = bytearray(payload[1 + ptr:])
        elif buf is not None:
            buf += payload
        else:
            continue

        if len(buf) >= 3:
            total = 3 + (((buf[1] & 0x0F) << 8) | buf[2])

            if len(buf) >= total:
                section = bytes(buf[:total])
                buf = None

                if section[0] in (0x42, 0x46):
                    name, provider = parse_sdt_section(section)

                    if name:
                        return name, provider

    return "", ""


# ----------------------------------------------------------------------
# Pomocnicze
# ----------------------------------------------------------------------

def natural_key(value):
    return [
        int(part) if part.isdigit() else part.lower()
        for part in re.split(r"(\d+)", value)
    ]


def split_template(template):
    """Zwraca (przed, zmienny_fragment, po) albo None."""
    m = BRACKET_RE.search(template)
    if m:
        return template[:m.start()], m.group(1), template[m.end():]

    m = LEGACY_RE.search(template)
    if m:
        return template[:m.start(1)], m.group(1), template[m.end(1):]

    return None


def make_variants(name):
    """Warianty zapisu: oryginał, małe litery, bez polskich znaków,
    oraz separatory '-', '_' i brak separatora."""
    base = name.strip()
    folded = base.replace("ł", "l").replace("Ł", "L")
    folded = "".join(
        c for c in unicodedata.normalize("NFKD", folded)
        if not unicodedata.combining(c)
    )

    out = []

    for cand in (base, folded):
        low = cand.lower()
        words = [w for w in re.split(r"[\s_\-]+", low) if w]

        for v in (
            cand,
            low,
            "-".join(words),
            "_".join(words),
            "".join(words),
        ):
            if v and v not in out:
                out.append(v)

    return out


class MarianScan:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("1100x780")
        self.root.minsize(820, 580)

        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.results = {}
        self.rows = []
        self.scanning = False
        self.finished = 0
        self.total = 0
        self.sdt_enabled = True

        self.url = tk.StringVar(
            value="http://57.128.231.171:8080/[306]/index.m3u8"
        )
        self.mode = tk.StringVar(value="numbers")
        self.start_num = tk.StringVar(value="306")
        self.end_num = tk.StringVar(value="1000")
        self.threads = tk.StringVar(value="15")
        self.timeout = tk.StringVar(value="5")
        self.variants = tk.BooleanVar(value=False)
        self.only_ok = tk.BooleanVar(value=False)
        self.use_sdt = tk.BooleanVar(value=True)
        self.block_adult = tk.BooleanVar(value=True)
        self.pl_filter = tk.StringVar(value=PL_FILTERS[0])
        self.status = tk.StringVar(value="Gotowy.")

        self.build_ui()
        self.on_mode_change()
        self.root.after(100, self.process_events)

    def build_ui(self):
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill="both", expand=True)

        ttk.Label(
            main,
            text="MarianTel Stream Scanner",
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w")

        ttk.Label(
            main,
            text="Skaner HLS/M3U8 z wykrywaniem nazw kanałów i PL"
        ).pack(anchor="w", pady=(0, 12))

        # --- Adres ---------------------------------------------------
        frame = ttk.LabelFrame(main, text="Adres bazowy", padding=8)
        frame.pack(fill="x", pady=4)

        url_row = ttk.Frame(frame)
        url_row.pack(fill="x")

        self.url_entry = ttk.Entry(
            url_row,
            textvariable=self.url,
            exportselection=False
        )
        self.url_entry.pack(side="left", fill="x", expand=True)

        ttk.Button(
            url_row,
            text="[ ] Zaznacz zmienny fragment",
            command=self.mark_selection
        ).pack(side="left", padx=(8, 0))

        ttk.Label(
            frame,
            text="Zmienny fragment ujmij w nawiasy kwadratowe, np. "
                 "http://serwer:8080/[tvp-rozrywka]/index.m3u8 "
                 "(albo zaznacz go myszką i kliknij przycisk).",
            foreground="#666666"
        ).pack(anchor="w", pady=(4, 0))

        # --- Ustawienia ----------------------------------------------
        settings = ttk.LabelFrame(main, text="Ustawienia", padding=8)
        settings.pack(fill="x", pady=4)

        mode_row = ttk.Frame(settings)
        mode_row.pack(fill="x", pady=(0, 6))

        ttk.Label(mode_row, text="Szukaj:").pack(side="left")
        ttk.Radiobutton(
            mode_row, text="Zakres liczb",
            variable=self.mode, value="numbers",
            command=self.on_mode_change
        ).pack(side="left", padx=(8, 0))
        ttk.Radiobutton(
            mode_row, text="Lista nazw",
            variable=self.mode, value="names",
            command=self.on_mode_change
        ).pack(side="left", padx=(8, 0))

        # Tryb: liczby
        self.numbers_frame = ttk.Frame(settings)

        for label, variable, width in [
            ("Od:", self.start_num, 8),
            ("Do:", self.end_num, 8),
        ]:
            ttk.Label(self.numbers_frame, text=label).pack(side="left")
            ttk.Entry(
                self.numbers_frame, textvariable=variable, width=width
            ).pack(side="left", padx=(5, 14))

        # Tryb: nazwy
        self.names_frame = ttk.Frame(settings)

        names_top = ttk.Frame(self.names_frame)
        names_top.pack(fill="x", pady=(0, 4))

        ttk.Label(
            names_top, text="Nazwy (jedna w linii):"
        ).pack(side="left")
        ttk.Button(
            names_top, text="Wczytaj z pliku…",
            command=self.load_names
        ).pack(side="left", padx=(10, 0))
        ttk.Button(
            names_top, text="Wstaw przykładowe",
            command=self.insert_default_names
        ).pack(side="left", padx=(6, 0))
        ttk.Checkbutton(
            names_top,
            text="Próbuj wariantów zapisu (małe litery, - _ , bez polskich znaków)",
            variable=self.variants
        ).pack(side="left", padx=(14, 0))

        names_box = ttk.Frame(self.names_frame)
        names_box.pack(fill="x")

        self.names_text = tk.Text(names_box, height=6, wrap="none")
        names_scroll = ttk.Scrollbar(
            names_box, orient="vertical",
            command=self.names_text.yview
        )
        self.names_text.configure(yscrollcommand=names_scroll.set)
        self.names_text.pack(side="left", fill="x", expand=True)
        names_scroll.pack(side="left", fill="y")

        self.names_text.insert("1.0", DEFAULT_NAMES)

        # Wspólne: wątki, timeout, SDT
        self.common_row = ttk.Frame(settings)

        for label, variable, width in [
            ("Wątki:", self.threads, 6),
            ("Timeout (s):", self.timeout, 6),
        ]:
            ttk.Label(self.common_row, text=label).pack(side="left")
            ttk.Entry(
                self.common_row, textvariable=variable, width=width
            ).pack(side="left", padx=(5, 14))

        ttk.Checkbutton(
            self.common_row,
            text="Wykrywaj nazwę ze strumienia (SDT, jak w VLC)",
            variable=self.use_sdt
        ).pack(side="left", padx=(6, 0))

        ttk.Checkbutton(
            self.common_row,
            text="Blokuj kanały erotyczne / XXX",
            variable=self.block_adult,
            command=self.refresh_table
        ).pack(side="left", padx=(14, 0))

        # --- Przyciski -----------------------------------------------
        buttons = ttk.Frame(main)
        buttons.pack(fill="x", pady=8)

        self.start_button = ttk.Button(
            buttons,
            text="▶ Skanuj",
            command=self.start_scan
        )
        self.start_button.pack(side="left")

        self.stop_button = ttk.Button(
            buttons,
            text="■ Stop",
            command=self.stop_scan,
            state="disabled"
        )
        self.stop_button.pack(side="left", padx=6)

        ttk.Button(
            buttons,
            text="Zapisz M3U",
            command=self.save_m3u
        ).pack(side="left", padx=6)

        ttk.Button(
            buttons,
            text="Wyczyść",
            command=self.clear_results
        ).pack(side="left", padx=6)

        # Filtry po prawej stronie (pack od prawej).
        pl_box = ttk.Combobox(
            buttons,
            textvariable=self.pl_filter,
            values=PL_FILTERS,
            state="readonly",
            width=20
        )
        pl_box.pack(side="right")
        pl_box.bind("<<ComboboxSelected>>", lambda e: self.refresh_table())

        ttk.Label(buttons, text="Filtr PL:").pack(
            side="right", padx=(0, 5)
        )

        ttk.Checkbutton(
            buttons,
            text="Tylko działające",
            variable=self.only_ok,
            command=self.refresh_table
        ).pack(side="right", padx=(0, 16))

        self.progress = ttk.Progressbar(
            main, mode="determinate"
        )
        self.progress.pack(fill="x", pady=(0, 5))

        ttk.Label(
            main, textvariable=self.status
        ).pack(anchor="w", pady=(0, 6))

        # --- Tabela --------------------------------------------------
        columns = (
            "number", "result", "name", "pl", "src",
            "group", "details", "url"
        )

        self.table = ttk.Treeview(
            main,
            columns=columns,
            show="headings"
        )

        headers = {
            "number": "Wartość",
            "result": "Status",
            "name": "Nazwa kanału",
            "pl": "PL",
            "src": "Źródło",
            "group": "Grupa",
            "details": "Szczegóły",
            "url": "Adres"
        }

        widths = {
            "number": 110,
            "result": 75,
            "name": 200,
            "pl": 45,
            "src": 60,
            "group": 110,
            "details": 140,
            "url": 360
        }

        for col in columns:
            self.table.heading(col, text=headers[col])
            self.table.column(
                col,
                width=widths[col],
                stretch=(col == "url")
            )

        self.table.tag_configure("pl", background="#dff3df")
        self.table.tag_configure("plmaybe", background="#fff4cc")

        scrollbar = ttk.Scrollbar(
            main,
            orient="vertical",
            command=self.table.yview
        )
        self.table.configure(yscrollcommand=scrollbar.set)

        self.table.pack(
            side="left", fill="both", expand=True
        )
        scrollbar.pack(side="right", fill="y")

    # ------------------------------------------------------------------
    # UI: tryby, zaznaczanie, lista nazw
    # ------------------------------------------------------------------

    def on_mode_change(self):
        self.numbers_frame.pack_forget()
        self.names_frame.pack_forget()
        self.common_row.pack_forget()

        if self.mode.get() == "numbers":
            self.numbers_frame.pack(fill="x")
        else:
            self.names_frame.pack(fill="x")

        self.common_row.pack(fill="x", pady=(6, 0))

    def mark_selection(self):
        try:
            a = self.url_entry.index("sel.first")
            b = self.url_entry.index("sel.last")
        except tk.TclError:
            messagebox.showinfo(
                "Zaznacz fragment",
                "Najpierw zaznacz myszką fragment adresu "
                "(np. tvp-rozrywka), potem kliknij ten przycisk."
            )
            return

        text = self.url.get()

        def strip(s):
            return s.replace("[", "").replace("]", "")

        inner = strip(text[a:b])

        if not inner:
            return

        self.url.set(
            strip(text[:a]) + "[" + inner + "]" + strip(text[b:])
        )

        # Dopasuj tryb do zaznaczonego fragmentu.
        if inner.isdigit():
            self.mode.set("numbers")
            self.start_num.set(inner)
        else:
            self.mode.set("names")

        self.on_mode_change()

    def load_names(self):
        path = filedialog.askopenfilename(
            title="Wczytaj listę nazw",
            filetypes=[
                ("Pliki tekstowe", "*.txt"),
                ("Wszystkie pliki", "*.*")
            ]
        )

        if not path:
            return

        try:
            with open(
                path, "r", encoding="utf-8", errors="replace"
            ) as f:
                content = f.read()
        except OSError as e:
            messagebox.showerror("Błąd odczytu", str(e))
            return

        self.names_text.delete("1.0", "end")
        self.names_text.insert("1.0", content)

    def insert_default_names(self):
        self.names_text.delete("1.0", "end")
        self.names_text.insert("1.0", DEFAULT_NAMES)

    def get_names(self):
        names = []
        seen = set()

        for line in self.names_text.get("1.0", "end").splitlines():
            line = line.strip()

            if not line or line.startswith("#"):
                continue

            candidates = (
                make_variants(line) if self.variants.get() else [line]
            )

            for cand in candidates:
                if cand not in seen:
                    seen.add(cand)
                    names.append(cand)

        return names

    # ------------------------------------------------------------------
    # Sieć i parsowanie
    # ------------------------------------------------------------------

    def make_url(self, template, value):
        parts = split_template(template)

        if not parts:
            return template

        before, _, after = parts
        return before + quote(str(value), safe="-_.~") + after

    def fetch(self, url, timeout, limit=512 * 1024):
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 MarianTelScanner/2.0",
                "Accept": "*/*"
            }
        )

        with urllib.request.urlopen(
            request, timeout=timeout
        ) as response:
            body = response.read(limit)
            return response.status, response.headers, body

    def parse_attributes(self, line):
        return {
            key.lower(): value
            for key, value in re.findall(
                r'([A-Za-z0-9_-]+)="([^"]*)"', line
            )
        }

    def extract_name(self, text):
        """Zwraca (nazwa, grupa, meta) z playlisty.
        meta = tvg-country / tvg-language / tvg-id (do wykrywania PL)."""
        name = ""
        group = ""
        meta = []

        for line in text.splitlines():
            line = line.strip()
            up = line.upper()

            # Standardowe rozszerzenia IPTV: EXTINF, tvg-name, group-title.
            if up.startswith("#EXTINF"):
                attrs = self.parse_attributes(line)

                for key in ("tvg-country", "tvg-language", "tvg-id"):
                    if attrs.get(key):
                        meta.append(f"{key}={attrs[key]}")

                if not name:
                    n = attrs.get("tvg-name", "").strip()
                    g = attrs.get("group-title", "").strip()

                    if not n and "," in line:
                        n = line.split(",", 1)[1].strip()

                    n = html.unescape(n)

                    if n and n.lower() not in (
                        "unknown", "undefined", "null"
                    ):
                        name, group = n, g

            # Nazwy wariantów w master playlist HLS.
            elif up.startswith("#EXT-X-MEDIA") and not name:
                attrs = self.parse_attributes(line)
                n = attrs.get("name", "").strip()

                if n:
                    name = html.unescape(n)

        return name, group, list(dict.fromkeys(meta))[:6]

    def find_child_playlist(self, base_url, text):
        lines = [
            line.strip()
            for line in text.splitlines()
            if line.strip()
        ]

        for i, line in enumerate(lines):
            if line.upper().startswith("#EXT-X-STREAM-INF"):
                for following in lines[i + 1:]:
                    if following.startswith("#"):
                        continue
                    if following.lower().endswith(
                        (".m3u8", ".m3u8?x")
                    ) or ".m3u8?" in following.lower():
                        return urljoin(base_url, following)
                    return None

        return None

    def find_segment(self, base_url, text):
        """Adres pierwszego segmentu TS z playlisty mediów."""
        if "#EXT-X-MAP" in text.upper():
            return None  # fMP4 - brak tabeli SDT

        for line in text.splitlines():
            line = line.strip()

            if not line or line.startswith("#"):
                continue

            low = line.lower().split("?", 1)[0]

            if low.endswith((
                ".m3u8", ".m4s", ".mp4", ".cmfv", ".cmfa",
                ".aac", ".mp3", ".ac3"
            )):
                return None

            return urljoin(base_url, line)

        return None

    def default_name(self, value):
        if str(value).isdigit():
            return f"Kanał {value}"
        return str(value)

    def make_result(self, value, good, url, details="",
                    name="", group="", pl="", src="", adult=False):
        return {
            "value": value,
            "good": good,
            "name": name,
            "group": group,
            "url": url,
            "pl": pl,
            "src": src,
            "details": details,
            "adult": adult,
        }

    def check_channel(self, value, url, timeout):
        try:
            status, headers, body = self.fetch(url, timeout)

            if status != 200:
                return self.make_result(
                    value, False, url, f"HTTP {status}"
                )

            text = body.decode(
                "utf-8", errors="replace"
            ).lstrip("\ufeff \r\n\t")

            if not text.startswith("#EXTM3U"):
                return self.make_result(
                    value, False, url, "Brak playlisty M3U8"
                )

            sdt = self.sdt_enabled

            name, group, meta = self.extract_name(text)
            src = "M3U" if name else ""

            media_url, media_text = url, text

            # Master playlist: pobierz playlistę wariantu
            # (potrzebna do nazwy i do odczytu segmentu).
            if (
                "#EXT-X-STREAM-INF" in text.upper()
                and (sdt or not name)
            ):
                child_url = self.find_child_playlist(url, text)

                if child_url:
                    try:
                        _, _, child_body = self.fetch(
                            child_url, timeout
                        )
                        child_text = child_body.decode(
                            "utf-8", errors="replace"
                        ).lstrip("\ufeff \r\n\t")

                        if child_text.startswith("#EXTM3U"):
                            media_url, media_text = child_url, child_text

                            c_name, c_group, c_meta = self.extract_name(
                                child_text
                            )
                            meta += c_meta

                            if not name and c_name:
                                name, group, src = c_name, c_group, "M3U"
                    except Exception:
                        pass

            # Nazwa usługi z SDT w pierwszym segmencie (jak VLC).
            sdt_name = ""
            provider = ""

            if sdt:
                seg_url = self.find_segment(media_url, media_text)

                if seg_url:
                    try:
                        _, _, seg = self.fetch(
                            seg_url, timeout, SEGMENT_PROBE_BYTES
                        )
                        sdt_name, provider = parse_ts_service(seg)
                    except Exception:
                        pass

            # Domyślne nazwy kodera (np. FFmpeg: "Service01") pomijamy.
            if sdt_name and re.fullmatch(
                r"(?i)service\d*|unknown|undefined|null", sdt_name
            ):
                sdt_name = ""

            if not name and sdt_name:
                name, src = sdt_name, "SDT"

            if not name:
                hdr = (
                    headers.get("icy-name")
                    or headers.get("x-channel-name")
                    or ""
                )
                hdr = html.unescape(hdr.strip())

                if hdr:
                    name, src = hdr, "HTTP"

            if not name:
                name, src = self.default_name(value), "-"

            pl = detect_pl(
                [name, group, sdt_name, provider],
                meta,
                [str(value)]
            )

            adult = is_adult(
                [name, group, sdt_name, provider, str(value)] + list(meta)
            )

            return self.make_result(
                value, True, url, "HLS OK",
                name=name, group=group, pl=pl, src=src, adult=adult
            )

        except urllib.error.HTTPError as e:
            return self.make_result(
                value, False, url, f"HTTP {e.code}"
            )

        except urllib.error.URLError as e:
            return self.make_result(
                value, False, url, str(getattr(e, "reason", e))
            )

        except Exception as e:
            return self.make_result(value, False, url, str(e))

    # ------------------------------------------------------------------
    # Skanowanie
    # ------------------------------------------------------------------

    def start_scan(self):
        if self.scanning:
            return

        template = self.url.get().strip()

        if not template.startswith(("http://", "https://")):
            messagebox.showerror(
                "Błąd", "Podaj adres HTTP lub HTTPS."
            )
            return

        if not split_template(template):
            messagebox.showerror(
                "Błędny adres",
                "Zaznacz zmienny fragment adresu w nawiasach "
                "kwadratowych.\n\n"
                "Przykłady:\n"
                "http://serwer:8080/[306]/index.m3u8\n"
                "http://serwer:8080/[tvp-rozrywka]/index.m3u8"
            )
            return

        try:
            workers = int(self.threads.get())
            timeout = float(self.timeout.get())

            if workers < 1 or workers > 100:
                raise ValueError("Wątki: od 1 do 100.")

            if timeout <= 0:
                raise ValueError("Timeout musi być większy od zera.")

            if self.mode.get() == "numbers":
                start = int(self.start_num.get())
                end = int(self.end_num.get())

                if start < 0 or end < start:
                    raise ValueError("Nieprawidłowy zakres numerów.")

                if end - start > 99999:
                    raise ValueError("Maksymalnie 100 000 adresów.")

                values = [str(n) for n in range(start, end + 1)]
            else:
                values = self.get_names()

                if not values:
                    raise ValueError("Lista nazw jest pusta.")

                if len(values) > 100000:
                    raise ValueError("Maksymalnie 100 000 adresów.")

        except ValueError as e:
            messagebox.showerror("Błędne ustawienia", str(e))
            return

        self.clear_results()
        self.stop_event.clear()
        self.scanning = True
        self.total = len(values)
        self.finished = 0

        # Zmienne Tk czytamy tylko w głównym wątku.
        self.sdt_enabled = self.use_sdt.get()

        self.progress["maximum"] = self.total
        self.progress["value"] = 0

        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")
        self.status.set(f"Rozpoczynam skanowanie {self.total} adresów...")

        threading.Thread(
            target=self.scan_worker,
            args=(template, values, workers, timeout),
            daemon=True
        ).start()

    def run_one(self, value, url, timeout):
        # Po kliknięciu Stop nie sprawdzamy już kolejnych adresów.
        if self.stop_event.is_set():
            return None

        result = self.check_channel(value, url, timeout)
        attempt = 0

        while (
            not result["good"]
            and attempt < retries_for(result["details"])
            and not self.stop_event.is_set()
        ):
            attempt += 1
            time.sleep(0.5 * attempt)
            result = self.check_channel(value, url, timeout)

        return result

    def scan_worker(self, template, values, workers, timeout):
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=workers
        ) as pool:

            futures = {}

            for value in values:
                url = self.make_url(template, value)

                future = pool.submit(
                    self.run_one,
                    value,
                    url,
                    timeout
                )
                futures[future] = (value, url)

            for future in concurrent.futures.as_completed(futures):
                try:
                    result = future.result()
                except Exception as e:
                    value, url = futures[future]
                    result = self.make_result(
                        value, False, url, str(e)
                    )

                if result is not None:
                    self.events.put(("result", result))

        self.events.put(("done", None))

    # ------------------------------------------------------------------
    # Tabela i filtry
    # ------------------------------------------------------------------

    def pl_pass(self, row):
        mode = self.pl_filter.get()

        if mode == PL_FILTERS[2]:
            return row["pl"] == "PL"

        if mode == PL_FILTERS[1]:
            return row["pl"] in ("PL", "pl?")

        return True

    def is_blocked(self, row):
        return bool(self.block_adult.get() and row.get("adult"))

    def row_visible(self, row):
        if self.is_blocked(row):
            return False

        if self.only_ok.get() and not row["good"]:
            return False

        return self.pl_pass(row)

    def insert_row(self, row):
        if row["pl"] == "PL":
            tags = ("pl",)
        elif row["pl"] == "pl?":
            tags = ("plmaybe",)
        else:
            tags = ()

        self.table.insert(
            "",
            "end",
            values=(
                row["value"],
                "DZIAŁA" if row["good"] else "BRAK",
                row["name"],
                row["pl"],
                row["src"],
                row["group"],
                row["details"],
                row["url"],
            ),
            tags=tags
        )

    def refresh_table(self):
        for item in self.table.get_children():
            self.table.delete(item)

        for row in self.rows:
            if self.row_visible(row):
                self.insert_row(row)

        if self.rows:
            self.update_status()

    def pl_counts(self):
        rows = [
            r for r in self.results.values() if not self.is_blocked(r)
        ]
        sure = sum(1 for r in rows if r["pl"] == "PL")
        maybe = sum(1 for r in rows if r["pl"] == "pl?")
        return sure, maybe

    def update_status(self):
        ok = sum(
            1 for r in self.results.values() if not self.is_blocked(r)
        )
        blocked = len(self.results) - ok
        sure, maybe = self.pl_counts()

        if self.scanning:
            head = (
                f"Sprawdzono: {self.finished}/{self.total} | "
                f"Działające: {ok}"
            )
        else:
            head = f"Koniec. Działających kanałów: {ok}"

        tail = f" | Zablokowane: {blocked}" if blocked else ""

        self.status.set(
            f"{head} | PL: {sure} (+{maybe} możliwych){tail}"
        )

    def process_events(self):
        try:
            while True:
                event, data = self.events.get_nowait()

                if event == "result":
                    row = data
                    self.finished += 1
                    self.rows.append(row)

                    if row["good"]:
                        self.results[row["value"]] = row

                    if self.row_visible(row):
                        self.insert_row(row)

                    self.progress["value"] = self.finished
                    self.update_status()

                elif event == "done":
                    self.scanning = False
                    self.start_button.config(state="normal")
                    self.stop_button.config(state="disabled")
                    self.update_status()

        except queue.Empty:
            pass

        self.root.after(100, self.process_events)

    def stop_scan(self):
        if self.scanning:
            self.stop_event.set()
            self.stop_button.config(state="disabled")
            self.status.set("Zatrzymywanie skanowania...")

    def clear_results(self):
        if self.scanning:
            return

        self.results.clear()
        self.rows.clear()

        for item in self.table.get_children():
            self.table.delete(item)

        self.progress["value"] = 0
        self.status.set("Wyczyszczono wyniki.")

    def save_m3u(self):
        if not self.results:
            messagebox.showinfo(
                "Brak kanałów",
                "Najpierw zeskanuj adresy."
            )
            return

        # Zapis uwzględnia filtr PL wybrany w oknie.
        items = [
            (value, info)
            for value, info in sorted(
                self.results.items(),
                key=lambda kv: natural_key(kv[0])
            )
            if self.pl_pass(info) and not self.is_blocked(info)
        ]

        if not items:
            messagebox.showinfo(
                "Brak kanałów",
                "Żaden kanał nie pasuje do filtrów (PL / blokada XXX)."
            )
            return

        path = filedialog.asksaveasfilename(
            title="Zapisz playlistę",
            defaultextension=".m3u",
            filetypes=[
                ("Playlisty M3U", "*.m3u"),
                ("Wszystkie pliki", "*.*")
            ]
        )

        if not path:
            return

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("#EXTM3U\n")

                for value, info in items:
                    name = info["name"] or self.default_name(value)
                    group = info["group"]

                    # Oczyść atrybuty, aby nie zepsuć pliku M3U.
                    safe_name = name.replace('"', "'")
                    safe_group = group.replace('"', "'")

                    attrs = f' tvg-name="{safe_name}"'

                    if safe_group:
                        attrs += f' group-title="{safe_group}"'

                    f.write(
                        f"#EXTINF:-1{attrs},{safe_name}\n"
                    )
                    f.write(info["url"] + "\n")

            messagebox.showinfo(
                "Zapisano",
                f"Zapisano {len(items)} kanałów "
                f"(filtr PL: {self.pl_filter.get()}):\n{path}"
            )

        except OSError as e:
            messagebox.showerror("Błąd zapisu", str(e))


if __name__ == "__main__":
    root = tk.Tk()
    app = MarianScan(root)
    root.mainloop()
